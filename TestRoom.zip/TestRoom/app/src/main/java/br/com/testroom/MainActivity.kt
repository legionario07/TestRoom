package br.com.testroom

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val userDao = RoomAppDb.getAppDataBase(this)?.userDao()

        val buttonInserir = findViewById<Button>(R.id.inserir)
        val buttonListar = findViewById<Button>(R.id.listar)

        buttonInserir.setOnClickListener { inserir() }
        buttonListar.setOnClickListener { listar() }
    }

    fun inserir(){
        Toast.makeText(this, "Inserir", Toast.LENGTH_LONG).show()
    }

    fun listar() {
        Toast.makeText(this, "Listar", Toast.LENGTH_LONG).show()
    }
}